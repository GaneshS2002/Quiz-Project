<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $finalscore = $_POST["finalscore"];

    // Connect to the MySQL database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mini";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Insert data into the database
    $sql = "INSERT INTO students (finalscore) VALUES ('$finalscore')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Student record inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>
