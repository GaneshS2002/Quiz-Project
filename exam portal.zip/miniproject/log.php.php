<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $college_name = $_POST["college_name"];
    $phone_number = $_POST["phone_number"];
    $registration_number = $_POST["registration_number"];
    
    // Connect to the MySQL database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mini";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Insert data into the database
    $sql = "INSERT INTO students (name, college_name, phone_number, registration_number) VALUES ('$name', '$college_name', '$phone_number', '$registration_number')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Student record inserted successfully.";
echo '<a href="file:///C:/xampp/htdocs/miniproject/second.html">CLICK HERE TO BEGIN QUIZ</a>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>
